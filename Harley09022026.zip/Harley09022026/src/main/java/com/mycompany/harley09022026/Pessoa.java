/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.harley09022026;

/**
 *
 * @author alunolab13
 */
public class Pessoa {
    String nome;
    int idade;
    
    String imprimir(){
        return "Meu nome é " + nome + " e minha idade é " + idade + " anos."; 
    }
    
}
